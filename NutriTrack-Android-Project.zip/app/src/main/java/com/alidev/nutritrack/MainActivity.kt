package com.alidev.nutritrack

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Nutrients(
    val calories: Double = 0.0,
    val protein: Double = 0.0,
    val carbs: Double = 0.0,
    val fat: Double = 0.0,
    val fiber: Double = 0.0
) {
    operator fun plus(other: Nutrients) = Nutrients(
        calories + other.calories, protein + other.protein, carbs + other.carbs,
        fat + other.fat, fiber + other.fiber
    )
    operator fun times(scale: Double) = Nutrients(
        calories * scale, protein * scale, carbs * scale, fat * scale, fiber * scale
    )
}

data class Food(val name: String, val servingGrams: Double, val nutrients: Nutrients)
data class MealEntry(val meal: String, val food: String, val grams: Double, val nutrients: Nutrients, val date: String)

private val defaultFoods = listOf(
    Food("تخم‌مرغ (۱۰۰ گرم)", 100.0, Nutrients(155.0, 13.0, 1.1, 11.0, 0.0)),
    Food("سینه مرغ پخته", 100.0, Nutrients(165.0, 31.0, 0.0, 3.6, 0.0)),
    Food("برنج پخته", 100.0, Nutrients(130.0, 2.7, 28.2, 0.3, 0.4)),
    Food("نان سنگک", 100.0, Nutrients(260.0, 8.5, 52.0, 1.5, 4.0)),
    Food("شیر", 100.0, Nutrients(61.0, 3.2, 4.8, 3.3, 0.0)),
    Food("ماست ساده", 100.0, Nutrients(61.0, 3.5, 4.7, 3.3, 0.0)),
    Food("موز", 100.0, Nutrients(89.0, 1.1, 22.8, 0.3, 2.6)),
    Food("جو دوسر خشک", 100.0, Nutrients(389.0, 16.9, 66.3, 6.9, 10.6)),
    Food("بادام", 100.0, Nutrients(579.0, 21.2, 21.6, 49.9, 12.5)),
    Food("سیب", 100.0, Nutrients(52.0, 0.3, 13.8, 0.2, 2.4))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NutriTrackApp(applicationContext) }
    }
}

@Composable
fun NutriTrackApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("nutritrack", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var goals by remember { mutableStateOf(loadGoals(prefs)) }
    var foods by remember { mutableStateOf(loadFoods(prefs)) }
    var entries by remember { mutableStateOf(loadEntries(prefs)) }
    var showAdd by remember { mutableStateOf(false) }
    var showFood by remember { mutableStateOf(false) }
    var showGoals by remember { mutableStateOf(false) }

    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val todayEntries = entries.filter { it.date == today }
    val total = todayEntries.fold(Nutrients()) { acc, item -> acc + item.nutrients }
    val scheme = if (dark) darkColorScheme() else lightColorScheme()

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Column {
                            Text("نوتری‌ترک", fontWeight = FontWeight.Bold)
                            Text("پیگیری تغذیه روزانه", style = MaterialTheme.typography.labelMedium)
                        } },
                        actions = {
                            TextButton(onClick = {
                                dark = !dark
                                prefs.edit().putBoolean("dark", dark).apply()
                            }) { Text(if (dark) "☀️ روشن" else "🌙 تاریک") }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                            icon = { Text("📊") }, label = { Text("امروز") })
                        NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                            icon = { Text("🥗") }, label = { Text("غذاها") })
                        NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                            icon = { Text("🎯") }, label = { Text("اهداف") })
                    }
                }
            ) { padding ->
                when (selectedTab) {
                    0 -> Dashboard(
                        modifier = Modifier.padding(padding), total = total, goals = goals,
                        entries = todayEntries,
                        onAdd = { showAdd = true },
                        onDelete = { entry -> entries = entries - entry; saveEntries(prefs, entries) }
                    )
                    1 -> FoodLibrary(
                        modifier = Modifier.padding(padding), foods = foods,
                        onAdd = { showFood = true }
                    )
                    else -> GoalsScreen(
                        modifier = Modifier.padding(padding), goals = goals,
                        onSave = { goals = it; saveGoals(prefs, it) }
                    )
                }
            }
        }

        if (showAdd) AddMealDialog(
            foods = foods,
            onDismiss = { showAdd = false },
            onSave = { entry ->
                entries = entries + entry
                saveEntries(prefs, entries)
                showAdd = false
            },
            today = today
        )
        if (showFood) AddFoodDialog(
            onDismiss = { showFood = false },
            onSave = { food ->
                foods = foods + food
                saveFoods(prefs, foods)
                showFood = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dashboard(
    modifier: Modifier, total: Nutrients, goals: Nutrients, entries: List<MealEntry>,
    onAdd: () -> Unit, onDelete: (MealEntry) -> Unit
) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("خلاصه امروز", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("${total.calories.toInt()} از ${goals.calories.toInt()} کیلوکالری", style = MaterialTheme.typography.titleMedium)
                    val fraction = if (goals.calories > 0) (total.calories / goals.calories).toFloat().coerceIn(0f, 1f) else 0f
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    Text(remainingText(total.calories, goals.calories, "کیلوکالری"), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        item { Text("مواد مغذی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { NutrientCard("پروتئین", total.protein, goals.protein, "گرم") }
        item { NutrientCard("کربوهیدرات", total.carbs, goals.carbs, "گرم") }
        item { NutrientCard("چربی", total.fat, goals.fat, "گرم") }
        item { NutrientCard("فیبر", total.fiber, goals.fiber, "گرم") }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("وعده‌های امروز", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(onClick = onAdd) { Text("+ افزودن غذا") }
            }
        }
        if (entries.isEmpty()) item {
            Card { Text("هنوز غذایی ثبت نکردی. برای شروع روی «افزودن غذا» بزن.", Modifier.padding(18.dp)) }
        }
        items(entries) { entry ->
            Card {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${entry.meal} • ${entry.food}", fontWeight = FontWeight.SemiBold)
                        Text("${entry.grams.toInt()} گرم  |  ${entry.nutrients.calories.toInt()} kcal")
                        Text("پروتئین ${entry.nutrients.protein.toInt()} گ • کربوهیدرات ${entry.nutrients.carbs.toInt()} گ")
                    }
                    TextButton(onClick = { onDelete(entry) }) { Text("حذف") }
                }
            }
        }
    }
}

@Composable
fun NutrientCard(title: String, consumed: Double, goal: Double, unit: String) {
    val remaining = goal - consumed
    val fraction = if (goal > 0) (consumed / goal).toFloat().coerceIn(0f, 1f) else 0f
    Card {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${consumed.toInt()} / ${goal.toInt()} $unit")
            }
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            Text(if (remaining >= 0) "باقی‌مانده: ${remaining.toInt()} $unit" else "بیشتر از هدف: ${(-remaining).toInt()} $unit",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

fun remainingText(consumed: Double, goal: Double, unit: String): String {
    val diff = goal - consumed
    return if (diff >= 0) "باقی‌مانده تا هدف: ${diff.toInt()} $unit" else "عبور از هدف: ${(-diff).toInt()} $unit"
}

@Composable
fun FoodLibrary(modifier: Modifier, foods: List<Food>, onAdd: () -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("فهرست غذاها", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Text("+ غذای جدید") }
        }
        Text("ارزش‌های غذایی فهرست، تقریبی هستند؛ برچسب محصول یا منبع معتبر را در اولویت قرار بده.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(foods) { food ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(food.name, fontWeight = FontWeight.Bold)
                        Text("مبنای ${food.servingGrams.toInt()} گرم • ${food.nutrients.calories.toInt()} kcal")
                        Text("پروتئین ${food.nutrients.protein} گ | کربوهیدرات ${food.nutrients.carbs} گ | چربی ${food.nutrients.fat} گ | فیبر ${food.nutrients.fiber} گ")
                    }
                }
            }
        }
    }
}

@Composable
fun GoalsScreen(modifier: Modifier, goals: Nutrients, onSave: (Nutrients) -> Unit) {
    var calories by remember(goals) { mutableStateOf(goals.calories.toString()) }
    var protein by remember(goals) { mutableStateOf(goals.protein.toString()) }
    var carbs by remember(goals) { mutableStateOf(goals.carbs.toString()) }
    var fat by remember(goals) { mutableStateOf(goals.fat.toString()) }
    var fiber by remember(goals) { mutableStateOf(goals.fiber.toString()) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("اهداف روزانه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("اهداف را می‌توانی از این صفحه تغییر بدهی. اعداد پیشنهادی، جایگزین مشاوره تخصصی تغذیه نیستند.")
        NumberField("کالری (kcal)", calories) { calories = it }
        NumberField("پروتئین (گرم)", protein) { protein = it }
        NumberField("کربوهیدرات (گرم)", carbs) { carbs = it }
        NumberField("چربی (گرم)", fat) { fat = it }
        NumberField("فیبر (گرم)", fiber) { fiber = it }
        Button(onClick = {
            onSave(Nutrients(calories.toDoubleOrNull() ?: 0.0, protein.toDoubleOrNull() ?: 0.0,
                carbs.toDoubleOrNull() ?: 0.0, fat.toDoubleOrNull() ?: 0.0, fiber.toDoubleOrNull() ?: 0.0))
        }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره اهداف") }
    }
}

@Composable
fun AddMealDialog(foods: List<Food>, today: String, onDismiss: () -> Unit, onSave: (MealEntry) -> Unit) {
    var meal by remember { mutableStateOf("صبحانه") }
    var foodName by remember { mutableStateOf(foods.firstOrNull()?.name ?: "") }
    var grams by remember { mutableStateOf("100") }
    var manual by remember { mutableStateOf(false) }
    var calories by remember { mutableStateOf("0") }
    var protein by remember { mutableStateOf("0") }
    var carbs by remember { mutableStateOf("0") }
    var fat by remember { mutableStateOf("0") }
    var fiber by remember { mutableStateOf("0") }
    val selectedFood = foods.find { it.name == foodName }
    val amount = grams.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val calculated = if (manual) Nutrients(calories.toDoubleOrNull() ?: 0.0, protein.toDoubleOrNull() ?: 0.0,
        carbs.toDoubleOrNull() ?: 0.0, fat.toDoubleOrNull() ?: 0.0, fiber.toDoubleOrNull() ?: 0.0)
        else (selectedFood?.nutrients ?: Nutrients()) * (amount / (selectedFood?.servingGrams ?: 100.0))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن وعده غذایی") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 520.dp)) {
                item {
                    Text("وعده")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("صبحانه", "ناهار", "شام", "میان‌وعده").forEach { label ->
                            FilterChip(selected = meal == label, onClick = { meal = label }, label = { Text(label) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = manual, onCheckedChange = { manual = it })
                        Text("ورود دستی مقادیر")
                    }
                }
                if (!manual) {
                    item {
                        Text("غذا")
                        foods.forEach { food ->
                            Row(Modifier.fillMaxWidth().clickable { foodName = food.name }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = foodName == food.name, onClick = { foodName = food.name })
                                Column {
                                    Text(food.name)
                                    Text("${food.nutrients.calories.toInt()} kcal در ${food.servingGrams.toInt()} گرم", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    item { NumberField("مقدار مصرف (گرم)", grams) { grams = it } }
                } else {
                    item {
                        NumberField("کالری (kcal)", calories) { calories = it }
                        NumberField("پروتئین (گرم)", protein) { protein = it }
                        NumberField("کربوهیدرات (گرم)", carbs) { carbs = it }
                        NumberField("چربی (گرم)", fat) { fat = it }
                        NumberField("فیبر (گرم)", fiber) { fiber = it }
                    }
                }
                item {
                    HorizontalDivider()
                    Text("مقدار ثبت‌شونده: ${calculated.calories.toInt()} kcal • پروتئین ${calculated.protein.toInt()} گ")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val name = if (manual) "غذای دستی" else foodName
                onSave(MealEntry(meal, name, if (manual) 1.0 else amount, calculated, today))
            }) { Text("ثبت غذا") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
fun AddFoodDialog(onDismiss: () -> Unit, onSave: (Food) -> Unit) {
    var name by remember { mutableStateOf("") }
    var calories by remember { mutableStateOf("0") }
    var protein by remember { mutableStateOf("0") }
    var carbs by remember { mutableStateOf("0") }
    var fat by remember { mutableStateOf("0") }
    var fiber by remember { mutableStateOf("0") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن غذای جدید") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 460.dp)) {
                item { OutlinedTextField(name, { name = it }, label = { Text("نام غذا") }, singleLine = true) }
                item { Text("مقادیر برای هر ۱۰۰ گرم") }
                item { NumberField("کالری (kcal)", calories) { calories = it } }
                item { NumberField("پروتئین (گرم)", protein) { protein = it } }
                item { NumberField("کربوهیدرات (گرم)", carbs) { carbs = it } }
                item { NumberField("چربی (گرم)", fat) { fat = it } }
                item { NumberField("فیبر (گرم)", fiber) { fiber = it } }
            }
        },
        confirmButton = {
            Button(enabled = name.isNotBlank(), onClick = {
                onSave(Food(name.trim(), 100.0, Nutrients(
                    calories.toDoubleOrNull() ?: 0.0, protein.toDoubleOrNull() ?: 0.0,
                    carbs.toDoubleOrNull() ?: 0.0, fat.toDoubleOrNull() ?: 0.0, fiber.toDoubleOrNull() ?: 0.0
                )))
            }) { Text("ذخیره غذا") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { input -> onValueChange(input.filter { it.isDigit() || it == '.' }) },
        label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

private fun loadGoals(prefs: android.content.SharedPreferences): Nutrients {
    val j = try { JSONObject(prefs.getString("goals", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    return Nutrients(j.optDouble("calories", 2800.0), j.optDouble("protein", 150.0),
        j.optDouble("carbs", 350.0), j.optDouble("fat", 80.0), j.optDouble("fiber", 30.0))
}
private fun saveGoals(prefs: android.content.SharedPreferences, n: Nutrients) {
    prefs.edit().putString("goals", JSONObject().put("calories", n.calories).put("protein", n.protein)
        .put("carbs", n.carbs).put("fat", n.fat).put("fiber", n.fiber).toString()).apply()
}
private fun loadFoods(prefs: android.content.SharedPreferences): List<Food> {
    val raw = prefs.getString("foods", null) ?: return defaultFoods
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val j = arr.getJSONObject(i); Food(j.getString("name"), j.optDouble("serving", 100.0),
                Nutrients(j.optDouble("calories"), j.optDouble("protein"), j.optDouble("carbs"), j.optDouble("fat"), j.optDouble("fiber")))
        }
    } catch (_: Exception) { defaultFoods }
}
private fun saveFoods(prefs: android.content.SharedPreferences, foods: List<Food>) {
    val arr = JSONArray()
    foods.forEach { f -> arr.put(JSONObject().put("name", f.name).put("serving", f.servingGrams)
        .put("calories", f.nutrients.calories).put("protein", f.nutrients.protein).put("carbs", f.nutrients.carbs)
        .put("fat", f.nutrients.fat).put("fiber", f.nutrients.fiber)) }
    prefs.edit().putString("foods", arr.toString()).apply()
}
private fun loadEntries(prefs: android.content.SharedPreferences): List<MealEntry> {
    val raw = prefs.getString("entries", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val j = arr.getJSONObject(i)
            MealEntry(j.getString("meal"), j.getString("food"), j.optDouble("grams", 100.0),
                Nutrients(j.optDouble("calories"), j.optDouble("protein"), j.optDouble("carbs"), j.optDouble("fat"), j.optDouble("fiber")),
                j.getString("date"))
        }
    } catch (_: Exception) { emptyList() }
}
private fun saveEntries(prefs: android.content.SharedPreferences, entries: List<MealEntry>) {
    val arr = JSONArray()
    entries.forEach { e -> arr.put(JSONObject().put("meal", e.meal).put("food", e.food).put("grams", e.grams)
        .put("calories", e.nutrients.calories).put("protein", e.nutrients.protein).put("carbs", e.nutrients.carbs)
        .put("fat", e.nutrients.fat).put("fiber", e.nutrients.fiber).put("date", e.date)) }
    prefs.edit().putString("entries", arr.toString()).apply()
}
